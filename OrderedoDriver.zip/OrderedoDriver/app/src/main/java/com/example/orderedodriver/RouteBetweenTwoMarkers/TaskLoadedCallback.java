package com.example.orderedodriver.RouteBetweenTwoMarkers;

public interface TaskLoadedCallback {
    void onTaskDone(Object... values);

}
