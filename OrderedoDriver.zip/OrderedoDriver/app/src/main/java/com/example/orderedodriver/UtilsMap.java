package com.example.orderedodriver;

import android.content.Context;
import android.widget.TextView;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;

public class UtilsMap {
//
//Context context;
//    static UtilsMap utilsMap;
//
//    public UtilsMap(Context context) {
//        this.context=context;
//    }
//
//    public synchronized static UtilsMap getInstance(Context context){
//      if (utilsMap == null){ //if there is no instance available... create new one
//          utilsMap = new UtilsMap(context);
//      }
//      return utilsMap;
//  }
//    public void  getLineInMap(GoogleMap map,LatLng cur, LatLng dis) {
//        String url = Directions.getInstance(context).getDirectionsUrl(cur,dis);
//        DownloadTask downloadTask = new DownloadTask(context,map,cur,dis);
//        downloadTask.execute(url);
//    }
//    public void  getTimeAndDes(TextView time , TextView delver,LatLng cur, LatLng dis) {
//        String url = Directions.getInstance(context).getDirectionsUrl(cur,dis);
//        DownloadTask downloadTask = new DownloadTask(context,time,delver,cur,dis);
//        downloadTask.execute(url);
//    }
//    public void  getAllMrakerInHomeMap(GoogleMap map, LatLng cur, LatLng dis, Marker marker) {
//        String url = Directions.getInstance(context).getDirectionsUrl(cur,dis);
//        DownloadTaskMarkerAll downloadTask = new DownloadTaskMarkerAll(context,map,cur,dis,marker);
//        downloadTask.execute(url);
//    }
}
