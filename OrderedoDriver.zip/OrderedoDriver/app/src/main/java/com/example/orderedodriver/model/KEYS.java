package com.example.orderedodriver.model;

public interface KEYS {
    public String UID = "UID";
    public String KEEPLOGIN = "UID";
    String BARCODE = "BARCODE";
    String CURRENTORDER = "CURRENTORDER";
}
